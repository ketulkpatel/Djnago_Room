from django.apps import AppConfig


class SonaConfig(AppConfig):
    name = 'sona'
