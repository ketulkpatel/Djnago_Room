from django.db import models

# Create your models here.
class Room(models.Model):
    price : models.IntegerField()

